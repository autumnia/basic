insert into user values(1, sysdate(), 'user1', 'pass111', '700823-1111111');
insert into user values(2, sysdate(), 'user2', 'pass222', '700823-2222222');
insert into user values(3, sysdate(), 'user3', 'pass333', '700823-3333333');


